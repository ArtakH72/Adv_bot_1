from config import API_TOKEN, admin_id
from messages import MESSAGE_about, Message_reward_2019, Message_reward_2020, Message_reward_2021
from messages import Message_reward_2022,Message_reward_2023, Message_reward_2024
from messages import Message_reward_gpk_kas, Message_end, Message_reward_upk_opponent




import asyncio
import logging
from aiogram import Bot, Dispatcher, types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.filters import Command


from aiogram import Bot, Dispatcher, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from datetime import datetime, timedelta
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from datetime import datetime, timedelta
from aiogram.filters import Command


#######################################################################################################

# Включаем логирование, чтобы не пропустить важные сообщения

logging.basicConfig(level=logging.INFO)

# Создаём бота и диспетчер
bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot=bot, storage=storage)  # Исправленная инициализация Dispatcher


#############################################################################################


# 🔹 Главное меню (4 кнопки)
main_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="ℹ О боте. Подсказка", callback_data="about_bot")],
        [InlineKeyboardButton(text="💰 Размер взносов в АПМ", callback_data="fees_apm")],
        [InlineKeyboardButton(text="📜 Решения Совета АПМ", callback_data="council_decisions")],
        [InlineKeyboardButton(text="⚖ Рекомендации по защите прав адвокатов", callback_data="lawyer_protection")]
    ]
)

# 🔹 Кнопки для "Размер взносов в АПМ"
fees_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📅 Взнос с 01.01.2024", callback_data="fees_2024_1")],
        [InlineKeyboardButton(text="📅 Взнос с 01.04.2024", callback_data="fees_2024_2")],
        [InlineKeyboardButton(text="📅 Взнос с 01.05.2025", callback_data="fees_2025")]
    ]
)

# 🔹 Кнопки для "Решения Совета АПМ"
council_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📄 Решение №11", callback_data="decision_11")],
        [InlineKeyboardButton(text="📄 Решение №13", callback_data="decision_13")],
        [InlineKeyboardButton(text="📄 Решение №15", callback_data="decision_15")]
    ]
)

# 🔹 Меню "Желаете продолжить?"
continue_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="✅ Да, хочу", callback_data="continue")],
        [InlineKeyboardButton(text="❌ Нет, спасибо", callback_data="end")]
    ]
)

# 🔹 Обработчик команды /start
@dp.message(Command("start"))
async def send_welcome(message: types.Message):
    username = message.from_user.full_name
    await message.answer(f"Привет, {username}! Выберите действие:", reply_markup=main_menu)

# 🔹 Обработчик кнопки "О боте. Подсказка"
@dp.callback_query(lambda c: c.data == "about_bot")
async def about_bot(callback: types.CallbackQuery):
    await callback.message.answer(
        "Добро пожаловать в адвокатский бот v1.6.\n\n"
        "📌 Он поможет вам узнать:\n"
        "✅ Размер обязательных отчислений\n"
        "✅ Решения Совета АПМ\n"
        "✅ Рекомендации по защите прав адвокатов\n",
        reply_markup=continue_keyboard
    )
    await callback.answer()

# 🔹 Обработчик кнопки "Размер взносов в АПМ"
@dp.callback_query(lambda c: c.data == "fees_apm")
async def fees_apm(callback: types.CallbackQuery):
    await callback.message.answer("Выберите период взноса:", reply_markup=fees_keyboard)
    await callback.answer()

# 🔹 Обработчики для размеров взносов
@dp.callback_query(lambda c: c.data == "fees_2024_1")
async def fees_2024_1(callback: types.CallbackQuery):
    await callback.message.answer("📌 Взнос с 01.01.2024 по 31.03.2024 составляет **1550 руб.**", reply_markup=continue_keyboard)
    await callback.answer()

@dp.callback_query(lambda c: c.data == "fees_2024_2")
async def fees_2024_2(callback: types.CallbackQuery):
    await callback.message.answer("📌 Взнос с 01.04.2024 составляет **1700 руб.**", reply_markup=continue_keyboard)
    await callback.answer()

@dp.callback_query(lambda c: c.data == "fees_2025")
async def fees_2025(callback: types.CallbackQuery):
    await callback.message.answer(
        "ℹ Размер взноса с 01.05.2025 пока не известен.\n"
        "Будет определён 04 апреля 2025 года.",
        reply_markup=continue_keyboard
    )
    await callback.answer()

# 🔹 Обработчик кнопки "Решения Совета АПМ"
@dp.callback_query(lambda c: c.data == "council_decisions")
async def council_decisions(callback: types.CallbackQuery):
    await callback.message.answer("Выберите документ:", reply_markup=council_keyboard)
    await callback.answer()

# 🔹 Обработчики для отправки PDF-файлов
async def send_pdf(callback: types.CallbackQuery, file_name: str):
    try:
        await callback.message.answer_document(types.FSInputFile(file_name), caption=f"📄 {file_name}")
    except Exception as e:
        await callback.message.answer(f"❌ Ошибка при отправке файла: {e}")
    await callback.answer()

@dp.callback_query(lambda c: c.data == "decision_11")
async def decision_11(callback: types.CallbackQuery):
    await send_pdf(callback, "Res_soveta_11.pdf")

@dp.callback_query(lambda c: c.data == "decision_13")
async def decision_13(callback: types.CallbackQuery):
    await send_pdf(callback, "Res_soveta_13.pdf")

@dp.callback_query(lambda c: c.data == "decision_15")
async def decision_15(callback: types.CallbackQuery):
    await send_pdf(callback, "Res_soveta_15.pdf")

# 🔹 Обработчик кнопки "Рекомендации по защите адвокатов"
@dp.callback_query(lambda c: c.data == "lawyer_protection")
async def lawyer_protection(callback: types.CallbackQuery):
    await callback.message.answer(
        "⚖ Ознакомьтесь с [рекомендациями по защите адвокатов](https://www.advokatymoscow.ru/advocate/legislation/prof-rights-protection/normativnye-akty/13758/).",
        reply_markup=continue_keyboard,
        disable_web_page_preview=True
    )
    await callback.answer()

# 🔹 Обработчик кнопки "Да, хочу" (повторяет меню)
@dp.callback_query(lambda c: c.data == "continue")
async def continue_bot(callback: types.CallbackQuery):
    await send_welcome(callback.message)
    await callback.answer()

# 🔹 Обработчик кнопки "Нет, спасибо" (завершает диалог)
@dp.callback_query(lambda c: c.data == "end")
async def end_bot(callback: types.CallbackQuery):
    await callback.message.answer("Спасибо, что воспользовались ботом! 👨‍⚖️")
    await callback.answer()

# 🔹 Запуск бота
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
