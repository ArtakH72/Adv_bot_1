{pkgs}: {
  deps = [
    pkgs.mailutils
  ];
}
