#Бот версии 1.2
#Исправлена ошибка при передаче списка длиной более 4096 возникала отбражения из SQL списка пользователей, которые использовали бота (лога работы). 


# Бот версии 1.3
# В новой версии бота добавлены следующие функции:
# введен массив вознаграждение по УПК РФ по годам, выборка размера во#знаграждения сделана из массива. 

# Бот версии 1.4
# Добавлена информация о размере обязательных ежемесячных отчислений на нужды АПМ в с 01.01.2024

# Бот версии 1.5
# Добавлена информация о количестве обращения за выбранный период времени
# Исправлена ошибка в обработчике кнопки "О боте. Подсказка", более не выдается ошибка, а выводится текст, после чего появляетстьс кнопочное с предложением продолжить работу/закончить работу

# Бот версии 1.6
# Исправленые мелкие ошибки по коду, 
# Используется один правильный вызов save_user_data()
# 🔄 База данных подключается и закрывается автоматически
# 🎯 Убраны дублирующиеся импорты
# ✅ Исправлены ошибки в обработчиках кнопок
# 🚀 Код стал чище и устойчивее к сбоям


###########################################################################################################

# НАДО СДЕЛАТЬ БОТА В ПОЛНОМ ВИДЕ
# Бот версии 1.7
# Бот выдает Постановление Пленума ВС РФ от 19.12.2013 года № 42 О практике применения судами законодательства о процессуальных издержках по уголовным делам (с изменениями, внесенными постановлениями Пленума от 15 мая 2018 г. № 11 и от 15 декабря 2022 г. № 38)


###########################################################################################################

import config

from messages import MESSAGE_about, Message_reward_2019, Message_reward_2020, Message_reward_2021
from messages import Message_reward_2022,Message_reward_2023, Message_reward_2024
from messages import Message_reward_gpk_kas, Message_end, Message_reward_upk_opponent

########################################################################################################

import logging
import sqlite3
import asyncio

from aiogram.filters import Command
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, ReplyKeyboardRemove


from aiogram import Bot, Dispatcher, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage

from datetime import datetime, timedelta
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from datetime import datetime, timedelta


########################################################################################################

# Включаем логирование, чтобы не пропустить важные сообщения
# Настраиваем логирование
#logging.basicConfig(level=logging.INFO)


# Создаём бота и диспетчер
bot = Bot(token=config.API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot=bot, storage=storage)  # Исправленная инициализация Dispatcher

########################################################################################################

# Подключение к базе данных
conn = sqlite3.connect("user_data.db")
cursor = conn.cursor()

# Создание таблицы для хранения данных
cursor.execute('''
CREATE TABLE IF NOT EXISTS user_data (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER,
    username TEXT,
    full_name TEXT,
    chat_id INTEGER,
    date TEXT,
    time TEXT
)
''')
conn.commit()

########################################################################################################

# Функция для сохранения данных в базу
def save_user_data(db_path, user_id, username, full_name, chat_id):
    try:
        # Подключение к базе
        with sqlite3.connect("user_data.db") as conn:
            cursor = conn.cursor()
           
            # Получаем дату и время
            date = datetime.now().strftime('%Y-%m-%d')
            time = datetime.now().strftime('%H:%M:%S')  

            # SQL-запрос с безопасными параметрами
            cursor.execute(
                """INSERT INTO user_data (user_id, username, full_name, chat_id, date, time) 
                   VALUES (?, ?, ?, ?, ?, ?)""",
                (user_id, username, full_name, chat_id, date, time)
            )

            # Фиксируем изменения
            conn.commit()
            print("✅ Данные успешно сохранены!")

    except sqlite3.IntegrityError:
        print("⚠ Ошибка: Такой пользователь уже существует (нарушение ограничения UNIQUE или PRIMARY KEY).")
    except sqlite3.OperationalError as e:
        print(f"⚠ Ошибка SQL: {e}. Проверь структуру таблицы или запрос.")
    except sqlite3.DatabaseError as e:
        print(f"❌ Ошибка базы данных: {e}. Возможно, база повреждена.")
    except sqlite3.InterfaceError as e:
        print(f"⚠ Ошибка интерфейса SQLite: {e}. Проблема с подключением.")
    except sqlite3.ProgrammingError as e:
        print(f"⚠ Ошибка программирования: {e}. Проверь синтаксис SQL-запроса.")
    except Exception as e:
        print(f"❌ Неизвестная ошибка: {e}.")
    finally:
        # Закрываем соединение (даже при ошибках)
        if conn:
            conn.close()

########################################################################################################

# Состояния для выбора периода
class UserPeriod(StatesGroup):
    choosing_period = State()

# Клавиатура с периодами
def get_period_keyboard():
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Сегодня", callback_data="period_today")],
            [InlineKeyboardButton(text="Вчера", callback_data="period_yesterday")],  # Исправлено
            [InlineKeyboardButton(text="Последняя неделя", callback_data="period_week")],
            [InlineKeyboardButton(text="Последний месяц", callback_data="period_month")]
        ]
    )

# Обработчик команды /users
@dp.message(Command("users"))
async def ask_period(message: Message, state: FSMContext):
    user_id = message.from_user.id
    if user_id == config.admin_id:
        await message.answer("За какой период вывести информацию?", reply_markup=get_period_keyboard())
        await state.set_state(UserPeriod.choosing_period)
    else:
        await message.answer("У вас нет доступа к этой команде.")


# Обработчик callback
@dp.callback_query(F.data.startswith("period_"))
async def show_users_by_period(callback: CallbackQuery, state: FSMContext):
        period = callback.data.split("_")[1]
        now = datetime.now()

        # Определяем границы периода
        if period == "today":
            start_date = now.strftime('%Y-%m-%d')
        elif period == "yesterday":  # Исправлено
            start_date = (now - timedelta(days=1)).strftime('%Y-%m-%d')
        elif period == "week":
            start_date = (now - timedelta(days=7)).strftime('%Y-%m-%d')
        elif period == "month":
            start_date = (now - timedelta(days=30)).strftime('%Y-%m-%d')
        else:
            await callback.answer("Неверный выбор периода!")
            return

        await callback.answer("Загрузка данных...")  # Уведомление о загрузке

# Извлекаем данные из базы
        try:
            cursor.execute("SELECT user_id, username, full_name, date, time FROM user_data WHERE date >= ?", (start_date,))
            users = cursor.fetchall()
        except Exception as e:
            print(f"Ошибка при извлечении данных: {e}")
            await callback.message.edit_text("Произошла ошибка при обработке запроса.")
            await state.clear()
            return

# Формируем ответ
        if users:
            response = f"Список пользователей с {start_date}:\n\n"
            for user in users:
                user_id, username, full_name, date, time = user
                response += (
                    f"ID: {user_id}\n"
                    f"Имя пользователя: @{username if username else 'не указано'}\n"
                    f"Полное имя: {full_name}\n"
                    f"Дата обращения: {date}\n"
                    f"Время обращения: {time}\n\n"
                )

# Разделяем сообщение на части
            parts = [response[i:i + 4000] for i in range(0, len(response), 4000)]

            try:
                # Отправляем части сообщений
                for index, part in enumerate(parts):
                    if index == 0:
                        await callback.message.edit_text(part)  # Первую часть отправляем с edit_text
                    else:
                        await callback.message.answer(part)  # Остальные части отправляем через answer

# Добавляем строку с общим количеством обращений
                total_users = len(users)
                summary = f"Всего было обращений за выбранный период: {total_users}"
                await callback.message.answer(summary)
            except Exception as e:
                print(f"Ошибка при отправке сообщения: {e}")
                await callback.answer("Произошла ошибка при обработке запроса.")
        else:
            response = f"Нет данных за выбранный период с {start_date}."
            await callback.message.edit_text(response)

        await state.clear()

############################################################################################################

# Обработчик команды /start
@dp.message(Command("start"))
async def send_welcome(message: Message):
    # Получение данных пользователя
    user_id = message.from_user.id
    username = message.from_user.username
    chat_id = message.chat.id

    full_name = f"{message.from_user.first_name} {message.from_user.last_name or ''}".strip()

# Сохранение данных пользователя
    save_user_data("user_data.db", user_id, username, full_name, chat_id)

# Создание клавиатуры
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="ℹ О боте. Подсказка", callback_data="about_choose")],
            [InlineKeyboardButton(text="💰 Размер взносов в АПМ", callback_data="razm_vzn")],
            [InlineKeyboardButton(text="📜 Разьяснения Совета АПМ № 11, № 13, № 15" , callback_data="resh_soveta")],
            [InlineKeyboardButton(text="📜 Разьяснения Совета АПМ № 16", callback_data="resh_soveta_16")],
            [InlineKeyboardButton(text="📜 Рекомендации по защите прав адвокатов", callback_data="lawyer_protection")],           
            [InlineKeyboardButton(text="🚕 Стоимость проезда", callback_data="cost")],
            [InlineKeyboardButton(text="💵 Размер вознаграждения", callback_data="reward")],
            #[InlineKeyboardButton(text="Окончить работу", callback_data="end_work")]
        ]
    )    
    
    await message.answer(f"Здравствуйте, {full_name}!\n\nВыберите опцию:", reply_markup=keyboard)

############################################################################################################

# Обработчик кнопки "О боте. Подсказка"

@dp.callback_query(F.data == "about_choose")
async def handle_about_choose(callback: CallbackQuery):

    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)

    new_text = MESSAGE_about["about_bot"]

    await callback.message.edit_text(new_text)  # Изменяем текст сообщения
    await ask_more(callback)

###########################################################################################################

# Обработчик нажатия на кнопку "Размер взносов в АПМ и ФПА"

# Клавиатура с тремя кнопками
@dp.callback_query(F.data == "razm_vzn")
async def handle_razm_vzn(callback: types.CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text='Размер взноса с 01.01.2024 по 31.03.2024', callback_data='razm_vzn_1')],
            [InlineKeyboardButton(text='Размер взноса с 01.04.2024', callback_data='razm_vzn_2')],
            [InlineKeyboardButton(text='Размер взноса с 01.05.2025', callback_data='razm_vzn_3')]
        ]
    )
    await callback.message.answer("Выберите размер взноса:", reply_markup=keyboard)

# Обработчик нажатия на кнопку "Размер взноса с 01.01.2024 по 31.03.2024 и 01.04.2024"
@dp.callback_query(F.data.in_({"razm_vzn_1", "razm_vzn_2", "razm_vzn_3"}))
async def handle_vzn_amount(callback: types.CallbackQuery):
    amounts = {
        "razm_vzn_1": "Размер обязательных отчислений (профессиональные расходы) на общие нужды Адвокатской палаты города Москвы составлял 1550 руб.",
        "razm_vzn_2": "Размер обязательных отчислений (профессиональные расходы) на общие нужды Адвокатской палаты города Москвы составляет 1700 руб."
    }    

    if callback.data in amounts:
        response_text = amounts[callback.data]
        
        # Имитация печатания
        await bot.send_chat_action(callback.message.chat.id, "typing")
        await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
        
        await callback.message.answer(response_text)

# Если выбрана опция 2025 года, отправляем дополнительное сообщение
    elif callback.data == "razm_vzn_3":
        
        # Имитация печатания
        await bot.send_chat_action(callback.message.chat.id, "typing")
        await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
        
        await callback.message.answer(
        "ℹ Размер взноса будет известен после решения 23-й ежегодной конференции адвокатов "
        "Адвокатской палаты города Москвы, которая состоится 04 апреля 2025 года."
        )

    await ask_more(callback)  

###########################################################################################################

# Обработчик нажатия на кнопку "Решения Совета АПМ № 11, № 13, № 15"

@dp.callback_query(lambda callback: callback.data == "resh_soveta")
async def handle_resh_soveta(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📄 Решение Совета № 11", callback_data="resh_soveta_11")],
            [InlineKeyboardButton(text="📄 Решение Совета № 13", callback_data="resh_soveta_13")],
            [InlineKeyboardButton(text="📄 Решение Совета № 15", callback_data="resh_soveta_15")],            
        ]
    )
    await callback.message.edit_text("Выберите файл для загрузки:", reply_markup=keyboard)
    await callback.answer()

@dp.callback_query(lambda callback: callback.data == "resh_soveta_11")
async def handle_resh_soveta_11(callback: CallbackQuery):
    file = FSInputFile("_№ 11_Reshenie_Soveta.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Решение Совета АПМ № 11'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "resh_soveta_13")
async def handle_resh_soveta_13(callback: CallbackQuery):
    file = FSInputFile("_№ 13_Reshenie_Soveta.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Решение Совета АПМ № 13'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "resh_soveta_15")
async def handle_resh_soveta_15(callback: CallbackQuery):
    file = FSInputFile("_№ 15_Reshenie_Soveta.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Решение Совета АПМ № 15'.")
    await ask_more(callback)

##########################################################################################################
# Обработчик нажатия на кнопку "Рекомендации по защите прав адвокатов"
# Выдает ссылку на страницу Рекомендации по защите прав адвокатов на сайте АПМ

@dp.callback_query(lambda query: query.data == "lawyer_protection")
async def lawyer_protection(callback_query: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback_query.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback_query.message.edit_text(
            text="Вот ссылка на нужную вам страницу: https://www.advokatymoscow.ru/advocate/legislation/prof-rights-protection/normativnye-akty/13758/"
    )
    await ask_more(callback_query)

###########################################################################################################
# Разъяснение № 16 Совета Адвокатской палаты города Москвы по вопросам профессиональной этики адвоката
# О действиях адвокатов по предотвращению оказания юридической помощи в условиях конфликта интересов, а также при наличии риска его возникновения

@dp.callback_query(F.data == "resh_soveta_16")
async def resh_soveta_16(callback_query: CallbackQuery):
    await callback_query.message.edit_text(
            text="Вот ссылка на нужную вам страницу: https://www.advokatymoscow.ru/advocate/docs/elucidate/14232/"
    )
    await ask_more(callback_query)

###########################################################################################################

# Обработчик нажатия на кнопку "Стоимость проезда"
@dp.callback_query(lambda callback: callback.data == "cost")
async def handle_cost(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[           
            [InlineKeyboardButton(text="Узнать стоимость проезда", callback_data="cost_choose")],
            [InlineKeyboardButton(text="Получить справку о стоимости проезда", callback_data="cost_info")]
        ]
    )
    await callback.message.edit_text("Что вы хотите сделать?", reply_markup=keyboard)
    await callback.answer()

###########################################################################################################

# Обработчик кнопки "Узнать стоимость проезда"
@dp.callback_query(lambda callback: callback.data == "cost_choose")
async def handle_cost_choose(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2025 года", callback_data="cost_2025")],
            [InlineKeyboardButton(text="Стоимость проезда с 20.05.2024 года", callback_data="cost_2024")],
            [InlineKeyboardButton(text="Стоимость проезда с 15.10.2023 года", callback_data="cost_2023")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2023 года", callback_data="cost_2023_early")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2022 года", callback_data="cost_2022")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2021 года", callback_data="cost_2021")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2020 года", callback_data="cost_2020")]
        ]
    )
    await callback.message.edit_text("Выберите период для получения информации о стоимости проезда:", reply_markup=keyboard)
    await callback.answer()

#Обработчик кнопки "Стоимости проезда с 02.01.2025 года"
@dp.callback_query(lambda callback: callback.data == "cost_2025")
async def handle_cost_2025(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 02.01.2025 года: 75 рублей.")
    await ask_more(callback)

#Обработчик кнопки "Стоимости проезда с 20.05.2024 года"
@dp.callback_query(lambda callback: callback.data == "cost_2024")
async def handle_cost_2024(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 20.05.2024 года: 70 рублей.")
    await ask_more(callback)

#Обработчик кнопки "Стоимости проезда с 15.10.2023 года"
@dp.callback_query(lambda callback: callback.data == "cost_2023")
async def handle_cost_2023(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 15.10.2023 года: 65 рублей.")
    await ask_more(callback)

#Обработчик кнопки "Стоимости проезда с 02.01.2023 года"
@dp.callback_query(lambda callback: callback.data == "cost_2023_early")
async def handle_cost_2023_early(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 02.01.2023 года составляет 62 рубля.")
    await ask_more(callback)

#Обработчик кнопки "Стоимости проезда с 02.01.2022 года"
@dp.callback_query(lambda callback: callback.data == "cost_2022")
async def handle_cost_2022(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 02.01.2022 года составляет 61 рубль.")
    await ask_more(callback)

#Обработчик кнопки "Стоимости проезда с 02.01.2021 года"
@dp.callback_query(lambda callback: callback.data == "cost_2021")
async def handle_cost_2021(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 02.01.2021 года составляет 60 рублей.")
    await ask_more(callback)

#Обработчик кнопки "Стоимости проезда с 02.01.2020 года"
@dp.callback_query(lambda callback: callback.data == "cost_2020")
async def handle_cost_2020(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    await callback.message.edit_text("Стоимость проезда с 02.01.2020 года составляет 57 рублей.")
    await ask_more(callback)

###########################################################################################################

# Обработчик кнопки "Получить справку о стоимости проезда"
@dp.callback_query(lambda callback: callback.data == "cost_info")
async def handle_cost_info(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2025 года", callback_data="info_2025")],
            [InlineKeyboardButton(text="Стоимость проезда с 20.05.2024 года", callback_data="info_2024")],
            [InlineKeyboardButton(text="Стоимость проезда с 15.10.2023 года", callback_data="info_2023_2")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2023 года", callback_data="info_2023_1")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2022 года", callback_data="info_2022")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2021 года", callback_data="info_2021")],
            [InlineKeyboardButton(text="Стоимость проезда с 02.01.2020 года", callback_data="info_2020")]
        ]
    )
    
    await callback.message.edit_text("Выберите файл для загрузки:", reply_markup=keyboard)
    await callback.answer()

@dp.callback_query(lambda callback: callback.data == "info_2025")
async def handle_info_2025(callback: CallbackQuery):
    file = FSInputFile("Проезд_2025.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2025'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "info_2024")
async def handle_info_2024(callback: CallbackQuery):
    file = FSInputFile("Проезд_2024.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2024'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "info_2023_2")
async def handle_info_2023_2(callback: CallbackQuery):
    file = FSInputFile("Проезд_2023-2.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2023-2'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "info_2023_1")
async def handle_info_2023_1(callback: CallbackQuery):
    file = FSInputFile("Проезд_2023-1.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2023-1'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "info_2022")
async def handle_info_2022(callback: CallbackQuery):
    file = FSInputFile("Проезд_2022.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2022'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "info_2021")
async def handle_info_2021(callback: CallbackQuery):
    file = FSInputFile("Проезд_2021.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2021'.")
    await ask_more(callback)

@dp.callback_query(lambda callback: callback.data == "info_2020")
async def handle_info_2020(callback: CallbackQuery):
    file = FSInputFile("Проезд_2020.pdf")
    await bot.send_document(chat_id=callback.message.chat.id, document=file, caption="Файл 'Проезд 2020'.")
    await ask_more(callback)
    
# Блок обработки кнопки "Стоимость проезда" завершен
    
###########################################################################################################

###########################################################################################################
    
###########################################################################################################

# Обработчик нажатия на кнопку "Размер вознаграждения"
@dp.callback_query(lambda callback: callback.data == "reward")
async def handle_reward(callback: CallbackQuery):
    main_reward_keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="Вознаграждение по УПК РФ как защитника", callback_data="reward_upk")],
            [InlineKeyboardButton(text="Вознаграждение по УПК РФ со стороны потерпевшего", callback_data="reward_upk_opponent")],
            [InlineKeyboardButton(text="Вознаграждение по ГПК РФ/КАС РФ", callback_data="reward_gpk_kas")]
        ]
    )
    await callback.message.edit_text("Выберите тип вознаграждения:", reply_markup=main_reward_keyboard)
    await callback.answer()


# Обработчик кнопки "Вознаграждение по УПК РФ как защитника
@dp.callback_query(lambda callback: callback.data == "reward_upk")
async def show_rewards(callback: types.CallbackQuery):
    await callback.message.edit_text("Выберите год вознаграждения:", reply_markup=reward_keyboard)
    await callback.answer()

# Завершение обработки кнопки "Вознаграждение по УПК РФ со строне потерпевшего"
@dp.callback_query(lambda callback: callback.data == "reward_upk_opponent")
async def show_rewards(callback: types.CallbackQuery):
      new_text = Message_reward_upk_opponent
      await callback.message.edit_text(new_text)
      await callback.answer()
      await ask_more(callback)

###########################################################################################################

# Клавиатура с кнопками вознаграждений по годам
reward_keyboard = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="Вознаграждение за 2019 год", callback_data="reward_2019")],
        [InlineKeyboardButton(text="Вознаграждение за 2020 год", callback_data="reward_2020")],
        [InlineKeyboardButton(text="Вознаграждение за 2021 год", callback_data="reward_2021")],
        [InlineKeyboardButton(text="Вознаграждение с 01.10.2022 года", callback_data="reward_2022")],
        [InlineKeyboardButton(text="Вознаграждение с 01.10.2023 года", callback_data="reward_2023")],
        [InlineKeyboardButton(text="Вознаграждение с 01.10.2024 года", callback_data="reward_2024")]
    ]
)


# Обработчик кнопки "Вознаграждение за 2019 год"
@dp.callback_query(lambda callback: callback.data == "reward_2019")
async def handle_reward_2019(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    new_text = Message_reward_2019
    await callback.message.edit_text(new_text) 
    await ask_more(callback)

# Обработчик кнопки "Вознаграждение за 2020 год"
@dp.callback_query(lambda callback: callback.data == "reward_2020")
async def handle_cost_2020(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    new_text = Message_reward_2020
    await callback.message.edit_text(new_text) 
    await ask_more(callback)

# Обработчик кнопки "Вознаграждение за 2021 год"
@dp.callback_query(lambda callback: callback.data == "reward_2021")
async def handle_cost_2021(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    new_text = Message_reward_2021
    await callback.message.edit_text(new_text) 
    await ask_more(callback)

# Обработчик кнопки "Вознаграждение за 2022 год"
@dp.callback_query(lambda callback: callback.data == "reward_2022")
async def handle_cost_2022(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    new_text = Message_reward_2022
    await callback.message.edit_text(new_text)
    await ask_more(callback)

# Обработчик кнопки "Вознаграждение за 2023 год"
@dp.callback_query(lambda callback: callback.data == "reward_2023")
async def handle_cost_2023(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    new_text = Message_reward_2023    
    await callback.message.edit_text(new_text)
    await ask_more(callback)

# Обработчик кнопки "Вознаграждение за 2024 год"
@dp.callback_query(lambda callback: callback.data == "reward_2024")
async def handle_cost_2024(callback: CallbackQuery):
    
    # Имитация печатания
    await bot.send_chat_action(callback.message.chat.id, "typing")
    await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
    new_text = Message_reward_2024
    await callback.message.edit_text(new_text)
    await ask_more(callback)

###########################################################################################################

# Обработчик кнопки "Вознаграждение по ГПК РФ/КАС РФ"
@dp.callback_query(lambda callback: callback.data == "reward_gpk_kas")
async def show_rewards(callback: types.CallbackQuery):
      
      # Имитация печатания
      await bot.send_chat_action(callback.message.chat.id, "typing")
      await asyncio.sleep(2)  # Фиксированная задержка вместо len(user_question)
    
      new_text = Message_reward_gpk_kas
      await callback.message.edit_text(new_text)
      await callback.answer()
      await ask_more(callback)

##########################################################################################################

# Обработчик меню "Еще желаете информацию?"
    
async def ask_more(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✅ Да, хочу", callback_data="yes_more")],
            [InlineKeyboardButton(text="❌ Нет, не хочу", callback_data="no_more")]
        ]
    )
    await callback.message.answer("Желаете еще получить информацию?", reply_markup=keyboard)
    await callback.answer()

###########################################################################################################

# Обработчик кнопки "Да, хочу"
@dp.callback_query(lambda callback: callback.data == "yes_more")
async def handle_yes_more(callback: CallbackQuery):
    await send_welcome(callback.message)
    await callback.answer()
    
###########################################################################################################

# Обработчик кнопки "Нет, не хочу"
@dp.callback_query(lambda callback: callback.data == "no_more")
async def handle_no_more(callback: CallbackQuery):
    keyboard = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="✍ Оставить отзыв", callback_data="leave_feedback")],
            [InlineKeyboardButton(text="🚪 Завершить работу", callback_data="end_work")]
        ]
    )
    await callback.message.answer("Вы хотите оставить отзыв о боте?", reply_markup=keyboard)
    await callback.answer()

###########################################################################################################

# Обработчик кнопки "Оставить отзыв"
@dp.callback_query(lambda callback: callback.data == "leave_feedback")
async def handle_feedback_request(callback: CallbackQuery):
    await callback.message.answer("Пожалуйста, напишите ваш отзыв и отправьте его в чат.")
    await callback.answer()

###########################################################################################################

# Обработчик текстового отзыва        
@dp.message()
async def receive_feedback(message: types.Message):
    if message.text:  # Проверяем, что это текст
        feedback = f"📩 Новый отзыв от @{message.from_user.username or message.from_user.id}:\n{message.text}"
        await bot.send_message(admin_id, feedback)  # Отправка админу
      
 # Завершаем работу (удаляем клавиатуру и уведомляем пользователя)
        await message.answer(
            f"✅ {Message_end}\n\nКлавиатура скрыта. До встречи! 👋",
            reply_markup=ReplyKeyboardRemove()
        )
   
###########################################################################################################

# Обработчик кнопки "Завершить работу"
@dp.callback_query(F.data == "end_work")
async def handle_end_work(callback: CallbackQuery):
    # 1. Убираем инлайн-кнопки, редактируя сообщение
    await callback.message.edit_text(f"✅ {Message_end}\n\nКлавиатура скрыта. До встречи! 👋", reply_markup=None)

    # 2. Убираем обычную (Reply) клавиатуру, если она была
    await bot.send_message(
        chat_id=callback.message.chat.id,  # Указываем чат, куда отправить сообщение
        text="Клавиатура скрыта.", 
        reply_markup=ReplyKeyboardRemove()
    )
    
    # 3. Подтверждаем callback-запрос, чтобы убрать "часики"
    await callback.answer()
###########################################################################################################

# Запуск бота
async def main():
    try:
        await bot.delete_webhook(drop_pending_updates=True)
        await dp.start_polling(bot)          # В aiogram 3 используется start_polling
    except KeyboardInterrupt:
        print("Бот остановлен вручную.")
    finally:
        await bot.session.close()
        conn.close()

if __name__ == "__main__":
    asyncio.run(main())
    
###########################################################################################################