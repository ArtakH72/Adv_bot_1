
import logging
import sqlite3
import asyncio

from aiogram import Bot, Dispatcher, F, types
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import Message, CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from datetime import datetime, timedelta
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext
from datetime import datetime, timedelta
from aiogram.filters import Command


from config import API_TOKEN, admin_id
from messages import MESSAGE_about, Message_reward_2019, Message_reward_2020, Message_reward_2021
from messages import Message_reward_2022,Message_reward_2023, Message_reward_2024
from messages import Message_reward_gpk_kas, Message_end, Message_reward_upk_opponent



# Включаем логирование, чтобы не пропустить важные сообщения

logging.basicConfig(level=logging.INFO)

# Создаём бота и диспетчер
bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot=bot, storage=storage)  # Исправленная инициализация Dispatcher




# Главное меню
main_menu = InlineKeyboardMarkup(
    inline_keyboard=[
        [InlineKeyboardButton(text="📜 Размер взносов в АПМ", callback_data="fees_info")],
        [InlineKeyboardButton(text="📄 Решения Совета АПМ", callback_data="council_decisions")],
        [InlineKeyboardButton(text="⚖ Рекомендации по защите прав адвокатов", callback_data="lawyer_protection")],
        [InlineKeyboardButton(text="🚕 Стоимость проезда", callback_data="travel_info")],
        [InlineKeyboardButton(text="ℹ О боте", callback_data="about_bot")]
    ]
)

# Обработчик команды /start
@dp.message(Command("start"))
async def send_welcome(message: types.Message):
    await message.answer(f"Привет, {message.from_user.full_name}!\nВыберите нужный раздел:", reply_markup=main_menu)

# Обработчик "О боте"
@dp.callback_query(lambda c: c.data == "about_bot")
async def about_bot(callback: types.CallbackQuery):
    await callback.message.answer("ℹ Этот бот предоставляет информацию по адвокатской практике, решениям Совета АПМ, стоимости проезда и рекомендациям по защите адвокатов.")
    await callback.answer()

# Обработчик "Решения Совета АПМ"
@dp.callback_query(lambda c: c.data == "council_decisions")
async def council_decisions(callback: types.CallbackQuery):
    decisions_menu = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📄 Решение №11", callback_data="decision_11")],
            [InlineKeyboardButton(text="📄 Решение №13", callback_data="decision_13")],
            [InlineKeyboardButton(text="📄 Решение №15", callback_data="decision_15")]
        ]
    )
    await callback.message.answer("Выберите нужное решение Совета:", reply_markup=decisions_menu)
    await callback.answer()

# Отправка PDF-файлов с решениями Совета
@dp.callback_query(lambda c: c.data.startswith("decision_"))
async def send_decision(callback: types.CallbackQuery):
    decision_number = callback.data.split("_")[-1]
    file_path = f"Res_soveta_{decision_number}.pdf"
    try:
        document = InputFile(file_path)
        await bot.send_document(chat_id=callback.from_user.id, document=document, caption=f"📄 Решение Совета №{decision_number}")
    except Exception as e:
        await callback.message.answer(f"Ошибка: Файл {file_path} не найден.")
    await callback.answer()

# Обработчик "Стоимость проезда"
@dp.callback_query(lambda c: c.data == "travel_info")
async def travel_info(callback: types.CallbackQuery):
    travel_menu = InlineKeyboardMarkup(
        inline_keyboard=[
            [InlineKeyboardButton(text="📄 Получить справку о стоимости проезда", callback_data="travel_certificate")],
            [InlineKeyboardButton(text="📊 Узнать тарифы на проезд", callback_data="travel_rates")]
        ]
    )
    await callback.message.answer("Выберите интересующую вас информацию о стоимости проезда:", reply_markup=travel_menu)
    await callback.answer()

# Обработчик "Справка о стоимости проезда"
@dp.callback_query(lambda c: c.data == "travel_certificate")
async def travel_certificate(callback: types.CallbackQuery):
    await callback.message.answer("📄 Для получения справки о стоимости проезда отправьте запрос в формате: \n\n🚗 'Справка проезд {год}'")
    await callback.answer()

# Обработчик "Текущие тарифы на проезд"
@dp.callback_query(lambda c: c.data == "travel_rates")
async def travel_rates(callback: types.CallbackQuery):
    fare_info = "💰 Текущие тарифы на проезд:\n\n"
    fare_info += "- 2020: 50 рублей\n"
    fare_info += "- 2021: 55 рублей\n"
    fare_info += "- 2022: 60 рублей\n"
    fare_info += "- 2023: 65 рублей\n"
    fare_info += "- 2024: 70 рублей\n"
    fare_info += "- 2025: 75 рублей\n"
    await callback.message.answer(fare_info)
    await callback.answer()

# Запуск бота
async def main():
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
