# Функция для сохранения данных в базу
def save_user_data(user_id, username, full_name, chat_id):
    try:
        date = datetime.now().strftime('%Y-%m-%d')
        time = datetime.now().strftime('%H:%M:%S')

        # Выполняем SQL-запрос
        cursor.execute(
            "INSERT INTO user_data (user_id, username, full_name, chat_id, date, time) VALUES (?, ?, ?, ?, ?, ?)",
            (user_id, username, full_name, chat_id, date, time)
        )
        conn.commit()
        print("Данные успешно сохранены!")
    except sqlite3.Error as e:
        print(f"Ошибка записи в базу данных: {e}")
